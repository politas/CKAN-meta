All metadata changes should be made through a mod's NetKAN file. See https://github.com/KSP-CKAN/NetKAN/issues/3890 for the reason. Or use this link: https://github.com/KSP-CKAN/NetKAN to go to the NetKAN repository.

The only reason to modify a .ckan is to modify earlier versions of a mod. If in doubt, just open an issue in NetKAN and we'll assist you as best we can.

Any PR that still contains this message will be summarily closed.
